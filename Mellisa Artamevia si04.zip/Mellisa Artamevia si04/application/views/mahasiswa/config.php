<?php 
$server = "localhost";
$username = "root";
$password = "";
$database = "dbelen";

$connect = mysqli_connect($server,$username,$password,$database) or die ("Gagal");
?>